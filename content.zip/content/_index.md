---
title: "MaYueLung"
description: "Welcome to my personal blog."
---

I write about language, digital culture, and living freely.
---

Hi, I'm **MaYueLung** 👋

Welcome to my personal blog.

I write about **language**, **digital culture**, and living freely.  
This site is powered by **Hugo**, themed by **Blowfish**, and deployed via **GitHub Pages**.