---
title: "Multiple Authors"
date: 2022-10-12
draft: false
description: "Sample for a multiple author setup"
tags: ["authors", "sample"]
summary: "A quick example of how multiple authors could be used."
showAuthor: false
authors:
  - "nunocoracao"
  - "secondauthor"
type: 'sample'
---

This is an example of how an article with multiple authors will look like. 