---
title: "Authors Taxonomy Listing Example"
---

A quick example of how to start using author taxonomies in your articles.
