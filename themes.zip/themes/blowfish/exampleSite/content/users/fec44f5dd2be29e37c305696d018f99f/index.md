---
                title: "ohdmire.github.io"
                tags: [Personal site]
                externalUrl: "https://ohdmire.github.io"
                weight: 471
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
